-- Assets addon: initial migration
-- Generated from compiled addon backend/addons/assets/

-- ============================================================
-- asset_categories
-- ============================================================
CREATE TABLE IF NOT EXISTS asset_categories (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id     UUID NOT NULL,
    created_at          TIMESTAMP DEFAULT now(),
    updated_at          TIMESTAMP DEFAULT now(),
    deleted_at          TIMESTAMP,
    created_by_id       UUID,
    name                VARCHAR(200) NOT NULL,
    code                VARCHAR(50),
    depreciation_method VARCHAR(30) DEFAULT 'straight_line',
    useful_life_months  INTEGER DEFAULT 60,
    salvage_rate        DOUBLE PRECISION DEFAULT 0.1,
    parent_id           UUID,
    is_active           BOOLEAN DEFAULT true
);

CREATE INDEX IF NOT EXISTS idx_asset_categories_organization_id ON asset_categories(organization_id);
CREATE INDEX IF NOT EXISTS idx_asset_categories_deleted_at ON asset_categories(deleted_at);

-- ============================================================
-- assets
-- ============================================================
CREATE TABLE IF NOT EXISTS assets (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id     UUID NOT NULL,
    created_at          TIMESTAMP DEFAULT now(),
    updated_at          TIMESTAMP DEFAULT now(),
    deleted_at          TIMESTAMP,
    created_by_id       UUID,
    category_id         UUID,
    name                VARCHAR(300) NOT NULL,
    code                VARCHAR(100),
    serial_number       VARCHAR(200),
    description         TEXT,
    purchase_date       DATE,
    purchase_cost       DOUBLE PRECISION DEFAULT 0,
    current_value       DOUBLE PRECISION DEFAULT 0,
    salvage_value       DOUBLE PRECISION DEFAULT 0,
    useful_life_months  INTEGER DEFAULT 60,
    depreciation_method VARCHAR(30) DEFAULT 'straight_line',
    location            VARCHAR(300),
    custodian_id        UUID,
    status              VARCHAR(20) DEFAULT 'active',
    warranty_expiry     DATE,
    notes               TEXT,
    image_url           VARCHAR(500)
);

CREATE INDEX IF NOT EXISTS idx_assets_organization_id ON assets(organization_id);
CREATE INDEX IF NOT EXISTS idx_assets_category_id ON assets(category_id);
CREATE INDEX IF NOT EXISTS idx_assets_status ON assets(status);
CREATE INDEX IF NOT EXISTS idx_assets_deleted_at ON assets(deleted_at);

-- ============================================================
-- depreciation_schedules
-- ============================================================
CREATE TABLE IF NOT EXISTS depreciation_schedules (
    id                         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id            UUID NOT NULL,
    created_at                 TIMESTAMP DEFAULT now(),
    updated_at                 TIMESTAMP DEFAULT now(),
    deleted_at                 TIMESTAMP,
    created_by_id              UUID,
    asset_id                   UUID NOT NULL,
    period_date                DATE NOT NULL,
    depreciation_amount        DOUBLE PRECISION DEFAULT 0,
    accumulated_depreciation   DOUBLE PRECISION DEFAULT 0,
    book_value                 DOUBLE PRECISION DEFAULT 0,
    journal_entry_id           UUID,
    is_posted                  BOOLEAN DEFAULT false
);

CREATE INDEX IF NOT EXISTS idx_depreciation_schedules_organization_id ON depreciation_schedules(organization_id);
CREATE INDEX IF NOT EXISTS idx_depreciation_schedules_asset_id ON depreciation_schedules(asset_id);
CREATE INDEX IF NOT EXISTS idx_depreciation_schedules_deleted_at ON depreciation_schedules(deleted_at);

-- ============================================================
-- maintenance_schedules
-- ============================================================
CREATE TABLE IF NOT EXISTS maintenance_schedules (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL,
    created_at      TIMESTAMP DEFAULT now(),
    updated_at      TIMESTAMP DEFAULT now(),
    deleted_at      TIMESTAMP,
    created_by_id   UUID,
    asset_id        UUID NOT NULL,
    title           VARCHAR(300) NOT NULL,
    description     TEXT,
    frequency       VARCHAR(20) DEFAULT 'monthly',
    next_due_date   DATE,
    assigned_to_id  UUID,
    is_active       BOOLEAN DEFAULT true
);

CREATE INDEX IF NOT EXISTS idx_maintenance_schedules_organization_id ON maintenance_schedules(organization_id);
CREATE INDEX IF NOT EXISTS idx_maintenance_schedules_asset_id ON maintenance_schedules(asset_id);
CREATE INDEX IF NOT EXISTS idx_maintenance_schedules_deleted_at ON maintenance_schedules(deleted_at);

-- ============================================================
-- maintenance_logs
-- ============================================================
CREATE TABLE IF NOT EXISTS maintenance_logs (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id  UUID NOT NULL,
    created_at       TIMESTAMP DEFAULT now(),
    updated_at       TIMESTAMP DEFAULT now(),
    deleted_at       TIMESTAMP,
    created_by_id    UUID,
    asset_id         UUID NOT NULL,
    schedule_id      UUID,
    maintenance_date DATE NOT NULL,
    description      TEXT,
    cost             DOUBLE PRECISION DEFAULT 0,
    performed_by     VARCHAR(200),
    performed_by_id  UUID,
    notes            TEXT
);

CREATE INDEX IF NOT EXISTS idx_maintenance_logs_organization_id ON maintenance_logs(organization_id);
CREATE INDEX IF NOT EXISTS idx_maintenance_logs_asset_id ON maintenance_logs(asset_id);
CREATE INDEX IF NOT EXISTS idx_maintenance_logs_deleted_at ON maintenance_logs(deleted_at);

-- ============================================================
-- asset_disposals
-- ============================================================
CREATE TABLE IF NOT EXISTS asset_disposals (
    id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id         UUID NOT NULL,
    created_at              TIMESTAMP DEFAULT now(),
    updated_at              TIMESTAMP DEFAULT now(),
    deleted_at              TIMESTAMP,
    created_by_id           UUID,
    asset_id                UUID NOT NULL,
    disposal_date           DATE NOT NULL,
    disposal_method         VARCHAR(30) NOT NULL,
    proceeds                DOUBLE PRECISION DEFAULT 0,
    book_value_at_disposal  DOUBLE PRECISION DEFAULT 0,
    gain_loss               DOUBLE PRECISION DEFAULT 0,
    journal_entry_id        UUID,
    notes                   TEXT
);

CREATE INDEX IF NOT EXISTS idx_asset_disposals_organization_id ON asset_disposals(organization_id);
CREATE INDEX IF NOT EXISTS idx_asset_disposals_asset_id ON asset_disposals(asset_id);
CREATE INDEX IF NOT EXISTS idx_asset_disposals_deleted_at ON asset_disposals(deleted_at);
