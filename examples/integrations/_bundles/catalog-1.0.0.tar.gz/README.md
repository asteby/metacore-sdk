# Catálogo de Productos

Gestiona un catálogo de productos con búsqueda inteligente por IA (RAG). El agente puede buscar, recomendar y compartir productos con precios, imágenes y descuentos.

- Category: `productivity`
- Tools: 2
