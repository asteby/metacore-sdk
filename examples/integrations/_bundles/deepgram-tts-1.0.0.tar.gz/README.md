# Deepgram — Texto a Voz

Convierte texto en audio con voces naturales de Deepgram Aura. Ideal para enviar notas de voz al usuario.

- Category: `communication`
- Tools: 1
