# Discord

Envía alertas y notificaciones a canales de Discord.

- Category: `communication`
- Tools: 1
