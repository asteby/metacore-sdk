# Google Sheets

Registra datos en hojas de cálculo de Google Sheets desde conversaciones.

- Category: `productivity`
- Tools: 1
