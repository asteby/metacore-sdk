-- HR addon: initial migration
-- Generated from compiled addon backend/addons/hr/

-- ============================================================
-- departments
-- ============================================================
CREATE TABLE IF NOT EXISTS departments (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL,
    created_at      TIMESTAMP DEFAULT now(),
    updated_at      TIMESTAMP DEFAULT now(),
    deleted_at      TIMESTAMP,
    created_by_id   UUID,
    parent_id       UUID,
    name            VARCHAR(200) NOT NULL,
    code            VARCHAR(50),
    manager_id      UUID,
    is_active       BOOLEAN DEFAULT true
);

CREATE INDEX IF NOT EXISTS idx_departments_organization_id ON departments(organization_id);
CREATE INDEX IF NOT EXISTS idx_departments_parent_id ON departments(parent_id);
CREATE INDEX IF NOT EXISTS idx_departments_manager_id ON departments(manager_id);
CREATE INDEX IF NOT EXISTS idx_departments_deleted_at ON departments(deleted_at);

-- ============================================================
-- positions
-- ============================================================
CREATE TABLE IF NOT EXISTS positions (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL,
    created_at      TIMESTAMP DEFAULT now(),
    updated_at      TIMESTAMP DEFAULT now(),
    deleted_at      TIMESTAMP,
    created_by_id   UUID,
    department_id   UUID,
    name            VARCHAR(200) NOT NULL,
    level           VARCHAR(50),
    is_active       BOOLEAN DEFAULT true
);

CREATE INDEX IF NOT EXISTS idx_positions_organization_id ON positions(organization_id);
CREATE INDEX IF NOT EXISTS idx_positions_department_id ON positions(department_id);
CREATE INDEX IF NOT EXISTS idx_positions_deleted_at ON positions(deleted_at);

-- ============================================================
-- employees
-- ============================================================
CREATE TABLE IF NOT EXISTS employees (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL,
    created_at      TIMESTAMP DEFAULT now(),
    updated_at      TIMESTAMP DEFAULT now(),
    deleted_at      TIMESTAMP,
    created_by_id   UUID,
    user_id         UUID,
    department_id   UUID,
    position_id     UUID,
    manager_id      UUID,
    first_name      VARCHAR(100) NOT NULL,
    last_name       VARCHAR(100) NOT NULL,
    employee_number VARCHAR(50),
    curp            VARCHAR(20),
    rfc             VARCHAR(15),
    imss            VARCHAR(20),
    email           VARCHAR(255),
    phone           VARCHAR(50),
    hire_date       TIMESTAMP,
    birth_date      TIMESTAMP,
    gender          VARCHAR(10),
    status          VARCHAR(20) DEFAULT 'active',
    bank_account    VARCHAR(50),
    clabe           VARCHAR(20),
    daily_salary    DOUBLE PRECISION DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_employees_organization_id ON employees(organization_id);
CREATE INDEX IF NOT EXISTS idx_employees_user_id ON employees(user_id);
CREATE INDEX IF NOT EXISTS idx_employees_department_id ON employees(department_id);
CREATE INDEX IF NOT EXISTS idx_employees_position_id ON employees(position_id);
CREATE INDEX IF NOT EXISTS idx_employees_manager_id ON employees(manager_id);
CREATE INDEX IF NOT EXISTS idx_employees_employee_number ON employees(employee_number);
CREATE INDEX IF NOT EXISTS idx_employees_curp ON employees(curp);
CREATE INDEX IF NOT EXISTS idx_employees_rfc ON employees(rfc);
CREATE INDEX IF NOT EXISTS idx_employees_deleted_at ON employees(deleted_at);

-- ============================================================
-- payroll_periods
-- ============================================================
CREATE TABLE IF NOT EXISTS payroll_periods (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL,
    created_at      TIMESTAMP DEFAULT now(),
    updated_at      TIMESTAMP DEFAULT now(),
    deleted_at      TIMESTAMP,
    created_by_id   UUID,
    name            VARCHAR(100) NOT NULL,
    period_type     VARCHAR(20),
    start_date      TIMESTAMP NOT NULL,
    end_date        TIMESTAMP NOT NULL,
    payment_date    TIMESTAMP NOT NULL,
    state           VARCHAR(20) DEFAULT 'draft'
);

CREATE INDEX IF NOT EXISTS idx_payroll_periods_organization_id ON payroll_periods(organization_id);
CREATE INDEX IF NOT EXISTS idx_payroll_periods_deleted_at ON payroll_periods(deleted_at);

-- ============================================================
-- payroll_entries
-- ============================================================
CREATE TABLE IF NOT EXISTS payroll_entries (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id   UUID NOT NULL,
    created_at        TIMESTAMP DEFAULT now(),
    updated_at        TIMESTAMP DEFAULT now(),
    deleted_at        TIMESTAMP,
    created_by_id     UUID,
    payroll_period_id UUID NOT NULL,
    employee_id       UUID NOT NULL,
    gross_salary      DOUBLE PRECISION DEFAULT 0,
    total_deductions  DOUBLE PRECISION DEFAULT 0,
    total_perceptions DOUBLE PRECISION DEFAULT 0,
    net_salary        DOUBLE PRECISION DEFAULT 0,
    state             VARCHAR(20) DEFAULT 'draft'
);

CREATE INDEX IF NOT EXISTS idx_payroll_entries_organization_id ON payroll_entries(organization_id);
CREATE INDEX IF NOT EXISTS idx_payroll_entries_payroll_period_id ON payroll_entries(payroll_period_id);
CREATE INDEX IF NOT EXISTS idx_payroll_entries_employee_id ON payroll_entries(employee_id);
CREATE INDEX IF NOT EXISTS idx_payroll_entries_deleted_at ON payroll_entries(deleted_at);

-- ============================================================
-- payroll_entry_lines
-- ============================================================
CREATE TABLE IF NOT EXISTS payroll_entry_lines (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    created_at       TIMESTAMP DEFAULT now(),
    updated_at       TIMESTAMP DEFAULT now(),
    deleted_at       TIMESTAMP,
    created_by_id    UUID,
    payroll_entry_id UUID NOT NULL,
    code             VARCHAR(50),
    name             VARCHAR(200) NOT NULL,
    line_type        VARCHAR(20),
    amount           DOUBLE PRECISION NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_payroll_entry_lines_payroll_entry_id ON payroll_entry_lines(payroll_entry_id);
CREATE INDEX IF NOT EXISTS idx_payroll_entry_lines_deleted_at ON payroll_entry_lines(deleted_at);

-- ============================================================
-- leave_types
-- ============================================================
CREATE TABLE IF NOT EXISTS leave_types (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id   UUID NOT NULL,
    created_at        TIMESTAMP DEFAULT now(),
    updated_at        TIMESTAMP DEFAULT now(),
    deleted_at        TIMESTAMP,
    created_by_id     UUID,
    name              VARCHAR(100) NOT NULL,
    code              VARCHAR(20) NOT NULL,
    is_paid           BOOLEAN DEFAULT true,
    max_days_per_year DOUBLE PRECISION DEFAULT 0,
    accrual_rate      DOUBLE PRECISION DEFAULT 0,
    carry_over        BOOLEAN DEFAULT false,
    max_carry_over    DOUBLE PRECISION DEFAULT 0,
    requires_doc      BOOLEAN DEFAULT false,
    is_active         BOOLEAN DEFAULT true,
    color             VARCHAR(20) DEFAULT 'blue'
);

CREATE INDEX IF NOT EXISTS idx_leave_types_organization_id ON leave_types(organization_id);
CREATE INDEX IF NOT EXISTS idx_leave_types_deleted_at ON leave_types(deleted_at);

-- ============================================================
-- leave_balances
-- ============================================================
CREATE TABLE IF NOT EXISTS leave_balances (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL,
    created_at      TIMESTAMP DEFAULT now(),
    updated_at      TIMESTAMP DEFAULT now(),
    deleted_at      TIMESTAMP,
    created_by_id   UUID,
    employee_id     UUID NOT NULL,
    leave_type_id   UUID NOT NULL,
    year            INTEGER NOT NULL,
    entitled        DOUBLE PRECISION DEFAULT 0,
    taken           DOUBLE PRECISION DEFAULT 0,
    accrued         DOUBLE PRECISION DEFAULT 0,
    carried_over    DOUBLE PRECISION DEFAULT 0,
    adjustment      DOUBLE PRECISION DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_leave_balances_organization_id ON leave_balances(organization_id);
CREATE INDEX IF NOT EXISTS idx_leave_balances_employee_id ON leave_balances(employee_id);
CREATE INDEX IF NOT EXISTS idx_leave_balances_leave_type_id ON leave_balances(leave_type_id);
CREATE INDEX IF NOT EXISTS idx_leave_balances_year ON leave_balances(year);
CREATE INDEX IF NOT EXISTS idx_leave_balances_deleted_at ON leave_balances(deleted_at);

-- ============================================================
-- leave_requests
-- ============================================================
CREATE TABLE IF NOT EXISTS leave_requests (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL,
    created_at      TIMESTAMP DEFAULT now(),
    updated_at      TIMESTAMP DEFAULT now(),
    deleted_at      TIMESTAMP,
    created_by_id   UUID,
    employee_id     UUID NOT NULL,
    leave_type_id   UUID NOT NULL,
    start_date      TIMESTAMP NOT NULL,
    end_date        TIMESTAMP NOT NULL,
    days            DOUBLE PRECISION NOT NULL,
    reason          VARCHAR(500),
    status          VARCHAR(20) DEFAULT 'pending',
    approver_id     UUID,
    approved_at     TIMESTAMP,
    rejection_note  VARCHAR(500),
    document_url    VARCHAR(500)
);

CREATE INDEX IF NOT EXISTS idx_leave_requests_organization_id ON leave_requests(organization_id);
CREATE INDEX IF NOT EXISTS idx_leave_requests_employee_id ON leave_requests(employee_id);
CREATE INDEX IF NOT EXISTS idx_leave_requests_leave_type_id ON leave_requests(leave_type_id);
CREATE INDEX IF NOT EXISTS idx_leave_requests_approver_id ON leave_requests(approver_id);
CREATE INDEX IF NOT EXISTS idx_leave_requests_deleted_at ON leave_requests(deleted_at);

-- ============================================================
-- leave_policies
-- ============================================================
CREATE TABLE IF NOT EXISTS leave_policies (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL,
    created_at      TIMESTAMP DEFAULT now(),
    updated_at      TIMESTAMP DEFAULT now(),
    deleted_at      TIMESTAMP,
    created_by_id   UUID,
    name            VARCHAR(100) NOT NULL,
    leave_type_id   UUID NOT NULL,
    department_id   UUID,
    position_id     UUID,
    days_per_year   DOUBLE PRECISION NOT NULL,
    accrual_rate    DOUBLE PRECISION DEFAULT 0,
    min_tenure      INTEGER DEFAULT 0,
    is_active       BOOLEAN DEFAULT true
);

CREATE INDEX IF NOT EXISTS idx_leave_policies_organization_id ON leave_policies(organization_id);
CREATE INDEX IF NOT EXISTS idx_leave_policies_leave_type_id ON leave_policies(leave_type_id);
CREATE INDEX IF NOT EXISTS idx_leave_policies_department_id ON leave_policies(department_id);
CREATE INDEX IF NOT EXISTS idx_leave_policies_position_id ON leave_policies(position_id);
CREATE INDEX IF NOT EXISTS idx_leave_policies_deleted_at ON leave_policies(deleted_at);

-- ============================================================
-- work_schedules
-- ============================================================
CREATE TABLE IF NOT EXISTS work_schedules (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL,
    created_at      TIMESTAMP DEFAULT now(),
    updated_at      TIMESTAMP DEFAULT now(),
    deleted_at      TIMESTAMP,
    created_by_id   UUID,
    name            VARCHAR(100) NOT NULL,
    description     VARCHAR(500),
    department_id   UUID,
    position_id     UUID,
    mon_start       VARCHAR(5),
    mon_end         VARCHAR(5),
    tue_start       VARCHAR(5),
    tue_end         VARCHAR(5),
    wed_start       VARCHAR(5),
    wed_end         VARCHAR(5),
    thu_start       VARCHAR(5),
    thu_end         VARCHAR(5),
    fri_start       VARCHAR(5),
    fri_end         VARCHAR(5),
    sat_start       VARCHAR(5),
    sat_end         VARCHAR(5),
    sun_start       VARCHAR(5),
    sun_end         VARCHAR(5),
    weekly_hours    DOUBLE PRECISION DEFAULT 48,
    is_active       BOOLEAN DEFAULT true
);

CREATE INDEX IF NOT EXISTS idx_work_schedules_organization_id ON work_schedules(organization_id);
CREATE INDEX IF NOT EXISTS idx_work_schedules_department_id ON work_schedules(department_id);
CREATE INDEX IF NOT EXISTS idx_work_schedules_position_id ON work_schedules(position_id);
CREATE INDEX IF NOT EXISTS idx_work_schedules_deleted_at ON work_schedules(deleted_at);

-- ============================================================
-- attendance_records
-- ============================================================
CREATE TABLE IF NOT EXISTS attendance_records (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL,
    created_at      TIMESTAMP DEFAULT now(),
    updated_at      TIMESTAMP DEFAULT now(),
    deleted_at      TIMESTAMP,
    created_by_id   UUID,
    employee_id     UUID NOT NULL,
    schedule_id     UUID,
    date            TIMESTAMP NOT NULL,
    clock_in        TIMESTAMP,
    clock_out       TIMESTAMP,
    break_start     TIMESTAMP,
    break_end       TIMESTAMP,
    worked_hours    DOUBLE PRECISION DEFAULT 0,
    overtime_hours  DOUBLE PRECISION DEFAULT 0,
    late_minutes    INTEGER DEFAULT 0,
    early_leave     INTEGER DEFAULT 0,
    status          VARCHAR(20) DEFAULT 'present',
    source          VARCHAR(20) DEFAULT 'manual',
    notes           VARCHAR(500),
    ip_address      VARCHAR(50)
);

CREATE INDEX IF NOT EXISTS idx_attendance_records_organization_id ON attendance_records(organization_id);
CREATE INDEX IF NOT EXISTS idx_attendance_records_employee_id ON attendance_records(employee_id);
CREATE INDEX IF NOT EXISTS idx_attendance_records_schedule_id ON attendance_records(schedule_id);
CREATE INDEX IF NOT EXISTS idx_attendance_records_date ON attendance_records(date);
CREATE INDEX IF NOT EXISTS idx_attendance_records_deleted_at ON attendance_records(deleted_at);

-- ============================================================
-- overtime_rules
-- ============================================================
CREATE TABLE IF NOT EXISTS overtime_rules (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id   UUID NOT NULL,
    created_at        TIMESTAMP DEFAULT now(),
    updated_at        TIMESTAMP DEFAULT now(),
    deleted_at        TIMESTAMP,
    created_by_id     UUID,
    name              VARCHAR(100) NOT NULL,
    department_id     UUID,
    daily_threshold   DOUBLE PRECISION DEFAULT 8,
    weekly_threshold  DOUBLE PRECISION DEFAULT 48,
    multiplier        DOUBLE PRECISION DEFAULT 1.5,
    double_multiplier DOUBLE PRECISION DEFAULT 2,
    double_threshold  DOUBLE PRECISION DEFAULT 12,
    requires_approval BOOLEAN DEFAULT true,
    is_active         BOOLEAN DEFAULT true
);

CREATE INDEX IF NOT EXISTS idx_overtime_rules_organization_id ON overtime_rules(organization_id);
CREATE INDEX IF NOT EXISTS idx_overtime_rules_department_id ON overtime_rules(department_id);
CREATE INDEX IF NOT EXISTS idx_overtime_rules_deleted_at ON overtime_rules(deleted_at);
