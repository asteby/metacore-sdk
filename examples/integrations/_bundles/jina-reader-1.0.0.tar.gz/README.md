# Lector de Páginas Web (Jina)

Extrae el contenido legible de cualquier URL: artículos, documentación, páginas de producto. Sin API key requerida.

- Category: `research`
- Tools: 1
