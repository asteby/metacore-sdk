-- Manufacturing addon: initial migration
-- Generated from compiled addon backend/addons/manufacturing/

-- ============================================================
-- bills_of_material
-- ============================================================
CREATE TABLE IF NOT EXISTS bills_of_material (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL,
    created_at      TIMESTAMP DEFAULT now(),
    updated_at      TIMESTAMP DEFAULT now(),
    deleted_at      TIMESTAMP,
    created_by_id   UUID,
    product_id      UUID,
    code            VARCHAR(50) NOT NULL,
    name            VARCHAR(200) NOT NULL,
    version         VARCHAR(20) DEFAULT '1.0',
    status          VARCHAR(20) DEFAULT 'draft',
    quantity        DOUBLE PRECISION DEFAULT 1,
    unit_of_measure VARCHAR(20) DEFAULT 'unit',
    notes           TEXT,
    is_active       BOOLEAN DEFAULT true
);

CREATE INDEX IF NOT EXISTS idx_bills_of_material_organization_id ON bills_of_material(organization_id);
CREATE INDEX IF NOT EXISTS idx_bills_of_material_product_id ON bills_of_material(product_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_bills_of_material_code ON bills_of_material(code);
CREATE INDEX IF NOT EXISTS idx_bills_of_material_deleted_at ON bills_of_material(deleted_at);

-- ============================================================
-- bom_lines
-- ============================================================
CREATE TABLE IF NOT EXISTS bom_lines (
    id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    created_at           TIMESTAMP DEFAULT now(),
    updated_at           TIMESTAMP DEFAULT now(),
    deleted_at           TIMESTAMP,
    created_by_id        UUID,
    bill_of_material_id  UUID NOT NULL,
    product_id           UUID,
    quantity             DOUBLE PRECISION NOT NULL DEFAULT 1,
    unit_of_measure      VARCHAR(20) DEFAULT 'unit',
    waste_percentage     DOUBLE PRECISION DEFAULT 0,
    notes                TEXT,
    sort_order           INTEGER DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_bom_lines_bill_of_material_id ON bom_lines(bill_of_material_id);
CREATE INDEX IF NOT EXISTS idx_bom_lines_product_id ON bom_lines(product_id);
CREATE INDEX IF NOT EXISTS idx_bom_lines_deleted_at ON bom_lines(deleted_at);

-- ============================================================
-- work_orders
-- ============================================================
CREATE TABLE IF NOT EXISTS work_orders (
    id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id      UUID NOT NULL,
    created_at           TIMESTAMP DEFAULT now(),
    updated_at           TIMESTAMP DEFAULT now(),
    deleted_at           TIMESTAMP,
    created_by_id        UUID,
    bill_of_material_id  UUID,
    order_number         VARCHAR(50) NOT NULL,
    product_id           UUID,
    quantity             DOUBLE PRECISION NOT NULL DEFAULT 1,
    completed_qty        DOUBLE PRECISION DEFAULT 0,
    unit_of_measure      VARCHAR(20) DEFAULT 'unit',
    status               VARCHAR(20) DEFAULT 'draft',
    priority             VARCHAR(20) DEFAULT 'medium',
    planned_start        TIMESTAMP,
    planned_end          TIMESTAMP,
    actual_start         TIMESTAMP,
    actual_end           TIMESTAMP,
    assigned_to_id       UUID,
    notes                TEXT,
    is_active            BOOLEAN DEFAULT true
);

CREATE INDEX IF NOT EXISTS idx_work_orders_organization_id ON work_orders(organization_id);
CREATE INDEX IF NOT EXISTS idx_work_orders_bill_of_material_id ON work_orders(bill_of_material_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_work_orders_order_number ON work_orders(order_number);
CREATE INDEX IF NOT EXISTS idx_work_orders_product_id ON work_orders(product_id);
CREATE INDEX IF NOT EXISTS idx_work_orders_status ON work_orders(status);
CREATE INDEX IF NOT EXISTS idx_work_orders_planned_start ON work_orders(planned_start);
CREATE INDEX IF NOT EXISTS idx_work_orders_assigned_to_id ON work_orders(assigned_to_id);
CREATE INDEX IF NOT EXISTS idx_work_orders_deleted_at ON work_orders(deleted_at);

-- ============================================================
-- production_schedules
-- ============================================================
CREATE TABLE IF NOT EXISTS production_schedules (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL,
    created_at      TIMESTAMP DEFAULT now(),
    updated_at      TIMESTAMP DEFAULT now(),
    deleted_at      TIMESTAMP,
    created_by_id   UUID,
    work_order_id   UUID,
    name            VARCHAR(200) NOT NULL,
    start_date      TIMESTAMP,
    end_date        TIMESTAMP,
    status          VARCHAR(20) DEFAULT 'planned',
    shift           VARCHAR(50),
    capacity        DOUBLE PRECISION DEFAULT 0,
    notes           TEXT,
    is_active       BOOLEAN DEFAULT true
);

CREATE INDEX IF NOT EXISTS idx_production_schedules_organization_id ON production_schedules(organization_id);
CREATE INDEX IF NOT EXISTS idx_production_schedules_work_order_id ON production_schedules(work_order_id);
CREATE INDEX IF NOT EXISTS idx_production_schedules_start_date ON production_schedules(start_date);
CREATE INDEX IF NOT EXISTS idx_production_schedules_status ON production_schedules(status);
CREATE INDEX IF NOT EXISTS idx_production_schedules_deleted_at ON production_schedules(deleted_at);
