# Pedidos

Registra y gestiona pedidos de venta directamente en Link. Sincroniza opcionalmente con Shopify u otras plataformas externas.

- Category: `productivity`
- Tools: 4
