-- Projects addon: initial migration
-- Generated from compiled addon backend/addons/projects/

-- ============================================================
-- Table: projects
-- ============================================================
CREATE TABLE IF NOT EXISTS projects (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL,
    created_at      TIMESTAMP DEFAULT now(),
    updated_at      TIMESTAMP DEFAULT now(),
    deleted_at      TIMESTAMP,
    created_by_id   UUID,

    manager_id      UUID,
    customer_id     UUID,
    code            VARCHAR(50) NOT NULL,
    name            VARCHAR(300) NOT NULL,
    description     TEXT,
    status          VARCHAR(20) DEFAULT 'planning',
    priority        VARCHAR(20) DEFAULT 'medium',
    start_date      TIMESTAMP,
    end_date        TIMESTAMP,
    budget          DOUBLE PRECISION DEFAULT 0,
    currency_code   VARCHAR(10) DEFAULT 'MXN',
    is_active       BOOLEAN DEFAULT true
);

CREATE INDEX IF NOT EXISTS idx_projects_organization_id ON projects(organization_id);
CREATE INDEX IF NOT EXISTS idx_projects_manager_id ON projects(manager_id);
CREATE INDEX IF NOT EXISTS idx_projects_customer_id ON projects(customer_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_projects_code ON projects(code);
CREATE INDEX IF NOT EXISTS idx_projects_status ON projects(status);
CREATE INDEX IF NOT EXISTS idx_projects_deleted_at ON projects(deleted_at);

-- ============================================================
-- Table: project_tasks
-- ============================================================
CREATE TABLE IF NOT EXISTS project_tasks (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL,
    created_at      TIMESTAMP DEFAULT now(),
    updated_at      TIMESTAMP DEFAULT now(),
    deleted_at      TIMESTAMP,
    created_by_id   UUID,

    project_id      UUID NOT NULL,
    parent_task_id  UUID,
    assignee_id     UUID,
    title           VARCHAR(300) NOT NULL,
    description     TEXT,
    status          VARCHAR(20) DEFAULT 'todo',
    priority        VARCHAR(20) DEFAULT 'medium',
    due_date        TIMESTAMP,
    estimated_hours DOUBLE PRECISION DEFAULT 0,
    actual_hours    DOUBLE PRECISION DEFAULT 0,
    sort_order      INTEGER DEFAULT 0,
    is_active       BOOLEAN DEFAULT true
);

CREATE INDEX IF NOT EXISTS idx_project_tasks_organization_id ON project_tasks(organization_id);
CREATE INDEX IF NOT EXISTS idx_project_tasks_project_id ON project_tasks(project_id);
CREATE INDEX IF NOT EXISTS idx_project_tasks_parent_task_id ON project_tasks(parent_task_id);
CREATE INDEX IF NOT EXISTS idx_project_tasks_assignee_id ON project_tasks(assignee_id);
CREATE INDEX IF NOT EXISTS idx_project_tasks_status ON project_tasks(status);
CREATE INDEX IF NOT EXISTS idx_project_tasks_deleted_at ON project_tasks(deleted_at);

-- ============================================================
-- Table: time_entries
-- ============================================================
CREATE TABLE IF NOT EXISTS time_entries (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL,
    created_at      TIMESTAMP DEFAULT now(),
    updated_at      TIMESTAMP DEFAULT now(),
    deleted_at      TIMESTAMP,
    created_by_id   UUID,

    project_id      UUID NOT NULL,
    task_id         UUID,
    employee_id     UUID,
    date            TIMESTAMP,
    hours           DOUBLE PRECISION NOT NULL DEFAULT 0,
    description     TEXT,
    is_billable     BOOLEAN DEFAULT true,
    is_active       BOOLEAN DEFAULT true
);

CREATE INDEX IF NOT EXISTS idx_time_entries_organization_id ON time_entries(organization_id);
CREATE INDEX IF NOT EXISTS idx_time_entries_project_id ON time_entries(project_id);
CREATE INDEX IF NOT EXISTS idx_time_entries_task_id ON time_entries(task_id);
CREATE INDEX IF NOT EXISTS idx_time_entries_employee_id ON time_entries(employee_id);
CREATE INDEX IF NOT EXISTS idx_time_entries_date ON time_entries(date);
CREATE INDEX IF NOT EXISTS idx_time_entries_deleted_at ON time_entries(deleted_at);
