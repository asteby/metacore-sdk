-- Quality addon: initial migration
-- Generated from compiled addon backend/addons/quality/

-- ============================================================
-- Table: quality_inspections
-- ============================================================
CREATE TABLE IF NOT EXISTS quality_inspections (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id   UUID NOT NULL,
    created_at        TIMESTAMP DEFAULT now(),
    updated_at        TIMESTAMP DEFAULT now(),
    deleted_at        TIMESTAMP,
    created_by_id     UUID,

    inspection_number VARCHAR(50) NOT NULL,
    type              VARCHAR(30) DEFAULT 'incoming',
    product_id        UUID,
    purchase_order_id UUID,
    supplier_id       UUID,
    status            VARCHAR(20) DEFAULT 'pending',
    sample_size       INTEGER DEFAULT 1,
    defects_found     INTEGER DEFAULT 0,
    result            VARCHAR(20),
    inspector_id      UUID,
    inspected_at      TIMESTAMP,
    notes             TEXT
);

CREATE INDEX IF NOT EXISTS idx_quality_inspections_organization_id ON quality_inspections(organization_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_quality_inspections_inspection_number ON quality_inspections(inspection_number);
CREATE INDEX IF NOT EXISTS idx_quality_inspections_product_id ON quality_inspections(product_id);
CREATE INDEX IF NOT EXISTS idx_quality_inspections_purchase_order_id ON quality_inspections(purchase_order_id);
CREATE INDEX IF NOT EXISTS idx_quality_inspections_supplier_id ON quality_inspections(supplier_id);
CREATE INDEX IF NOT EXISTS idx_quality_inspections_status ON quality_inspections(status);
CREATE INDEX IF NOT EXISTS idx_quality_inspections_inspector_id ON quality_inspections(inspector_id);
CREATE INDEX IF NOT EXISTS idx_quality_inspections_deleted_at ON quality_inspections(deleted_at);

-- ============================================================
-- Table: inspection_lines
-- ============================================================
CREATE TABLE IF NOT EXISTS inspection_lines (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL,
    created_at      TIMESTAMP DEFAULT now(),
    updated_at      TIMESTAMP DEFAULT now(),
    deleted_at      TIMESTAMP,
    created_by_id   UUID,

    inspection_id   UUID NOT NULL,
    product_id      UUID,
    parameter       VARCHAR(200) NOT NULL,
    specification   VARCHAR(200),
    measured_value   VARCHAR(200),
    unit            VARCHAR(20),
    result          VARCHAR(20) DEFAULT 'pending',
    defects_found   INTEGER DEFAULT 0,
    notes           TEXT
);

CREATE INDEX IF NOT EXISTS idx_inspection_lines_organization_id ON inspection_lines(organization_id);
CREATE INDEX IF NOT EXISTS idx_inspection_lines_inspection_id ON inspection_lines(inspection_id);
CREATE INDEX IF NOT EXISTS idx_inspection_lines_product_id ON inspection_lines(product_id);
CREATE INDEX IF NOT EXISTS idx_inspection_lines_deleted_at ON inspection_lines(deleted_at);

-- ============================================================
-- Table: defect_reports
-- ============================================================
CREATE TABLE IF NOT EXISTS defect_reports (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL,
    created_at      TIMESTAMP DEFAULT now(),
    updated_at      TIMESTAMP DEFAULT now(),
    deleted_at      TIMESTAMP,
    created_by_id   UUID,

    inspection_id   UUID,
    product_id      UUID,
    report_number   VARCHAR(50) NOT NULL,
    defect_type     VARCHAR(50) NOT NULL,
    severity        VARCHAR(20) DEFAULT 'minor',
    quantity        INTEGER DEFAULT 1,
    description     TEXT NOT NULL,
    root_cause      TEXT,
    disposition     VARCHAR(30),
    reported_by_id  UUID,
    resolved_at     TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_defect_reports_organization_id ON defect_reports(organization_id);
CREATE INDEX IF NOT EXISTS idx_defect_reports_inspection_id ON defect_reports(inspection_id);
CREATE INDEX IF NOT EXISTS idx_defect_reports_product_id ON defect_reports(product_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_defect_reports_report_number ON defect_reports(report_number);
CREATE INDEX IF NOT EXISTS idx_defect_reports_reported_by_id ON defect_reports(reported_by_id);
CREATE INDEX IF NOT EXISTS idx_defect_reports_deleted_at ON defect_reports(deleted_at);

-- ============================================================
-- Table: non_conformances
-- ============================================================
CREATE TABLE IF NOT EXISTS non_conformances (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL,
    created_at      TIMESTAMP DEFAULT now(),
    updated_at      TIMESTAMP DEFAULT now(),
    deleted_at      TIMESTAMP,
    created_by_id   UUID,

    ncr_number      VARCHAR(50) NOT NULL,
    title           VARCHAR(200) NOT NULL,
    description     TEXT NOT NULL,
    source          VARCHAR(30),
    status          VARCHAR(20) DEFAULT 'open',
    severity        VARCHAR(20) DEFAULT 'minor',
    product_id      UUID,
    inspection_id   UUID,
    assigned_to_id  UUID,
    root_cause      TEXT,
    closed_at       TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_non_conformances_organization_id ON non_conformances(organization_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_non_conformances_ncr_number ON non_conformances(ncr_number);
CREATE INDEX IF NOT EXISTS idx_non_conformances_status ON non_conformances(status);
CREATE INDEX IF NOT EXISTS idx_non_conformances_product_id ON non_conformances(product_id);
CREATE INDEX IF NOT EXISTS idx_non_conformances_inspection_id ON non_conformances(inspection_id);
CREATE INDEX IF NOT EXISTS idx_non_conformances_assigned_to_id ON non_conformances(assigned_to_id);
CREATE INDEX IF NOT EXISTS idx_non_conformances_deleted_at ON non_conformances(deleted_at);

-- ============================================================
-- Table: corrective_actions
-- ============================================================
CREATE TABLE IF NOT EXISTS corrective_actions (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id     UUID NOT NULL,
    created_at          TIMESTAMP DEFAULT now(),
    updated_at          TIMESTAMP DEFAULT now(),
    deleted_at          TIMESTAMP,
    created_by_id       UUID,

    non_conformance_id  UUID NOT NULL,
    action_number       VARCHAR(50) NOT NULL,
    type                VARCHAR(30) DEFAULT 'corrective',
    description         TEXT NOT NULL,
    status              VARCHAR(20) DEFAULT 'planned',
    assigned_to_id      UUID,
    due_date            TIMESTAMP,
    completed_at        TIMESTAMP,
    verified_by_id      UUID,
    verified_at         TIMESTAMP,
    effectiveness_note  TEXT
);

CREATE INDEX IF NOT EXISTS idx_corrective_actions_organization_id ON corrective_actions(organization_id);
CREATE INDEX IF NOT EXISTS idx_corrective_actions_non_conformance_id ON corrective_actions(non_conformance_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_corrective_actions_action_number ON corrective_actions(action_number);
CREATE INDEX IF NOT EXISTS idx_corrective_actions_status ON corrective_actions(status);
CREATE INDEX IF NOT EXISTS idx_corrective_actions_assigned_to_id ON corrective_actions(assigned_to_id);
CREATE INDEX IF NOT EXISTS idx_corrective_actions_verified_by_id ON corrective_actions(verified_by_id);
CREATE INDEX IF NOT EXISTS idx_corrective_actions_deleted_at ON corrective_actions(deleted_at);
