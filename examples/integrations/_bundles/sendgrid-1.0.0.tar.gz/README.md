# SendGrid

Envía correos transaccionales con SendGrid de Twilio.

- Category: `email`
- Tools: 1
