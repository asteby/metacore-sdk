# Slack

Envía notificaciones a canales de Slack cuando ocurren eventos importantes.

- Category: `communication`
- Tools: 1
