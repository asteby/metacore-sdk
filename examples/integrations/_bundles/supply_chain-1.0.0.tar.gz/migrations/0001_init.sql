-- Supply Chain addon: initial migration
-- Generated from compiled addon backend/addons/supply_chain/

-- ============================================================
-- Table: rfqs
-- ============================================================
CREATE TABLE IF NOT EXISTS rfqs (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL,
    created_at      TIMESTAMP DEFAULT now(),
    updated_at      TIMESTAMP DEFAULT now(),
    deleted_at      TIMESTAMP,
    created_by_id   UUID,

    supplier_id     UUID,
    rfq_number      VARCHAR(50) NOT NULL,
    title           VARCHAR(200) NOT NULL,
    status          VARCHAR(20) DEFAULT 'draft',
    deadline        TIMESTAMP,
    total_amount    DOUBLE PRECISION DEFAULT 0,
    currency_code   VARCHAR(10) DEFAULT 'MXN',
    notes           TEXT,
    sent_at         TIMESTAMP,
    received_at     TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_rfqs_organization_id ON rfqs(organization_id);
CREATE INDEX IF NOT EXISTS idx_rfqs_supplier_id ON rfqs(supplier_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_rfqs_rfq_number ON rfqs(rfq_number);
CREATE INDEX IF NOT EXISTS idx_rfqs_status ON rfqs(status);
CREATE INDEX IF NOT EXISTS idx_rfqs_deleted_at ON rfqs(deleted_at);

-- ============================================================
-- Table: rfq_lines
-- ============================================================
CREATE TABLE IF NOT EXISTS rfq_lines (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL,
    created_at      TIMESTAMP DEFAULT now(),
    updated_at      TIMESTAMP DEFAULT now(),
    deleted_at      TIMESTAMP,
    created_by_id   UUID,

    rfq_id          UUID NOT NULL,
    product_id      UUID,
    description     VARCHAR(500) NOT NULL,
    quantity        DOUBLE PRECISION NOT NULL DEFAULT 1,
    unit_of_measure VARCHAR(20) DEFAULT 'pza',
    unit_price      DOUBLE PRECISION DEFAULT 0,
    total_price     DOUBLE PRECISION DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_rfq_lines_organization_id ON rfq_lines(organization_id);
CREATE INDEX IF NOT EXISTS idx_rfq_lines_rfq_id ON rfq_lines(rfq_id);
CREATE INDEX IF NOT EXISTS idx_rfq_lines_product_id ON rfq_lines(product_id);
CREATE INDEX IF NOT EXISTS idx_rfq_lines_deleted_at ON rfq_lines(deleted_at);

-- ============================================================
-- Table: vendor_scorecards
-- ============================================================
CREATE TABLE IF NOT EXISTS vendor_scorecards (
    id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id      UUID NOT NULL,
    created_at           TIMESTAMP DEFAULT now(),
    updated_at           TIMESTAMP DEFAULT now(),
    deleted_at           TIMESTAMP,
    created_by_id        UUID,

    supplier_id          UUID NOT NULL,
    period               VARCHAR(20) NOT NULL,
    quality_score        DOUBLE PRECISION DEFAULT 0,
    delivery_score       DOUBLE PRECISION DEFAULT 0,
    price_score          DOUBLE PRECISION DEFAULT 0,
    responsiveness_score DOUBLE PRECISION DEFAULT 0,
    overall_score        DOUBLE PRECISION DEFAULT 0,
    orders_placed        INTEGER DEFAULT 0,
    orders_on_time       INTEGER DEFAULT 0,
    defect_rate          DOUBLE PRECISION DEFAULT 0,
    notes                TEXT,
    reviewed_by_id       UUID,
    reviewed_at          TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_vendor_scorecards_organization_id ON vendor_scorecards(organization_id);
CREATE INDEX IF NOT EXISTS idx_vendor_scorecards_supplier_id ON vendor_scorecards(supplier_id);
CREATE INDEX IF NOT EXISTS idx_vendor_scorecards_reviewed_by_id ON vendor_scorecards(reviewed_by_id);
CREATE INDEX IF NOT EXISTS idx_vendor_scorecards_deleted_at ON vendor_scorecards(deleted_at);

-- ============================================================
-- Table: supplier_contracts
-- ============================================================
CREATE TABLE IF NOT EXISTS supplier_contracts (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL,
    created_at      TIMESTAMP DEFAULT now(),
    updated_at      TIMESTAMP DEFAULT now(),
    deleted_at      TIMESTAMP,
    created_by_id   UUID,

    supplier_id     UUID NOT NULL,
    contract_number VARCHAR(50) NOT NULL,
    title           VARCHAR(200) NOT NULL,
    status          VARCHAR(20) DEFAULT 'draft',
    start_date      TIMESTAMP NOT NULL,
    end_date        TIMESTAMP NOT NULL,
    total_value     DOUBLE PRECISION DEFAULT 0,
    currency_code   VARCHAR(10) DEFAULT 'MXN',
    payment_terms   VARCHAR(100),
    auto_renew      BOOLEAN DEFAULT false,
    terms           TEXT,
    signed_by_id    UUID,
    signed_at       TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_supplier_contracts_organization_id ON supplier_contracts(organization_id);
CREATE INDEX IF NOT EXISTS idx_supplier_contracts_supplier_id ON supplier_contracts(supplier_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_supplier_contracts_contract_number ON supplier_contracts(contract_number);
CREATE INDEX IF NOT EXISTS idx_supplier_contracts_signed_by_id ON supplier_contracts(signed_by_id);
CREATE INDEX IF NOT EXISTS idx_supplier_contracts_deleted_at ON supplier_contracts(deleted_at);
