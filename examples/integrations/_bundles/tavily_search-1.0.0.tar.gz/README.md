# Búsqueda Web (Tavily)

Busca en Internet y obtiene resultados actualizados con IA. Ideal para responder preguntas que requieren información reciente o fuentes externas.

- Category: `research`
- Tools: 1
