# Tickets

Registra y gestiona tickets de soporte directamente en Link, sin necesidad de GitHub, Jira u otra plataforma externa.

- Category: `productivity`
- Tools: 4
