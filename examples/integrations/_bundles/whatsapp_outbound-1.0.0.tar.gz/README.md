# WhatsApp — Envío Externo

El agente envía mensajes a otros números y gestiona contactos usando el dispositivo de la conversación activa.

- Category: `communication`
- Tools: 2
