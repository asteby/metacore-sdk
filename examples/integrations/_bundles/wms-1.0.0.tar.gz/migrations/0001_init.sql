-- WMS addon: initial schema
-- Tables: pick_orders, pick_lines, packing_slips, shipment_labels, barcode_configs

CREATE TABLE IF NOT EXISTS pick_orders (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL,
    created_by_id   UUID,
    sales_order_id  UUID,
    warehouse_id    UUID,
    assigned_to_id  UUID,
    status          VARCHAR(20) NOT NULL DEFAULT 'pending',
    priority        VARCHAR(10) NOT NULL DEFAULT 'normal',
    picked_at       TIMESTAMPTZ,
    notes           TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at      TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_pick_orders_organization_id ON pick_orders(organization_id);
CREATE INDEX IF NOT EXISTS idx_pick_orders_sales_order_id  ON pick_orders(sales_order_id);
CREATE INDEX IF NOT EXISTS idx_pick_orders_warehouse_id    ON pick_orders(warehouse_id);
CREATE INDEX IF NOT EXISTS idx_pick_orders_assigned_to_id  ON pick_orders(assigned_to_id);
CREATE INDEX IF NOT EXISTS idx_pick_orders_status          ON pick_orders(status);

CREATE TABLE IF NOT EXISTS pick_lines (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL,
    created_by_id   UUID,
    pick_order_id   UUID NOT NULL,
    product_id      UUID NOT NULL,
    location_bin    VARCHAR(50),
    quantity_needed DOUBLE PRECISION NOT NULL DEFAULT 0,
    quantity_picked DOUBLE PRECISION DEFAULT 0,
    status          VARCHAR(20) NOT NULL DEFAULT 'pending',
    scanned_barcode VARCHAR(100),
    picked_by_id    UUID,
    picked_at       TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at      TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_pick_lines_organization_id ON pick_lines(organization_id);
CREATE INDEX IF NOT EXISTS idx_pick_lines_pick_order_id   ON pick_lines(pick_order_id);
CREATE INDEX IF NOT EXISTS idx_pick_lines_product_id      ON pick_lines(product_id);
CREATE INDEX IF NOT EXISTS idx_pick_lines_picked_by_id    ON pick_lines(picked_by_id);

CREATE TABLE IF NOT EXISTS packing_slips (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL,
    created_by_id   UUID,
    pick_order_id   UUID,
    sales_order_id  UUID,
    slip_number     VARCHAR(50) NOT NULL,
    status          VARCHAR(20) NOT NULL DEFAULT 'draft',
    total_items     INTEGER DEFAULT 0,
    total_weight    DOUBLE PRECISION DEFAULT 0,
    weight_unit     VARCHAR(10) DEFAULT 'kg',
    packed_by_id    UUID,
    packed_at       TIMESTAMPTZ,
    notes           TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at      TIMESTAMPTZ
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_packing_slips_slip_number   ON packing_slips(slip_number);
CREATE INDEX IF NOT EXISTS idx_packing_slips_organization_id      ON packing_slips(organization_id);
CREATE INDEX IF NOT EXISTS idx_packing_slips_pick_order_id        ON packing_slips(pick_order_id);
CREATE INDEX IF NOT EXISTS idx_packing_slips_sales_order_id       ON packing_slips(sales_order_id);
CREATE INDEX IF NOT EXISTS idx_packing_slips_packed_by_id         ON packing_slips(packed_by_id);

CREATE TABLE IF NOT EXISTS shipment_labels (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL,
    created_by_id   UUID,
    packing_slip_id UUID,
    sales_order_id  UUID,
    tracking_number VARCHAR(100),
    carrier         VARCHAR(100),
    service_type    VARCHAR(50),
    status          VARCHAR(20) NOT NULL DEFAULT 'created',
    ship_to_name    VARCHAR(200),
    ship_to_address TEXT,
    ship_to_city    VARCHAR(100),
    ship_to_state   VARCHAR(100),
    ship_to_zip     VARCHAR(20),
    weight          DOUBLE PRECISION DEFAULT 0,
    shipping_cost   DOUBLE PRECISION DEFAULT 0,
    shipped_at      TIMESTAMPTZ,
    delivered_at    TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at      TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_shipment_labels_organization_id ON shipment_labels(organization_id);
CREATE INDEX IF NOT EXISTS idx_shipment_labels_packing_slip_id ON shipment_labels(packing_slip_id);
CREATE INDEX IF NOT EXISTS idx_shipment_labels_sales_order_id  ON shipment_labels(sales_order_id);
CREATE INDEX IF NOT EXISTS idx_shipment_labels_tracking_number ON shipment_labels(tracking_number);

CREATE TABLE IF NOT EXISTS barcode_configs (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id  UUID NOT NULL,
    created_by_id    UUID,
    name             VARCHAR(100) NOT NULL,
    barcode_type     VARCHAR(30) NOT NULL DEFAULT 'code128',
    prefix           VARCHAR(20),
    sequence_start   INTEGER DEFAULT 1,
    sequence_current INTEGER DEFAULT 1,
    is_active        BOOLEAN DEFAULT true,
    applies_to       VARCHAR(30),
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at       TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_barcode_configs_organization_id ON barcode_configs(organization_id);
