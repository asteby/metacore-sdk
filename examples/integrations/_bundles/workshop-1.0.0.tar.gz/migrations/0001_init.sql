-- Taller Automotriz addon: initial schema
-- Tables: workshop_work_orders, workshop_work_order_items, workshop_service_bays, workshop_labor_items

CREATE TABLE IF NOT EXISTS workshop_work_orders (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id  UUID NOT NULL,
    created_by_id    UUID,
    customer_id      UUID NOT NULL,
    service_bay_id   UUID,
    technician_id    UUID,
    number           VARCHAR(50),
    vehicle_plate    VARCHAR(20),
    vehicle_brand    VARCHAR(100),
    vehicle_model    VARCHAR(100),
    vehicle_year     INTEGER,
    vehicle_km       INTEGER,
    vehicle_vin      VARCHAR(20),
    customer_notes   TEXT,
    technician_notes TEXT,
    state            VARCHAR(20) NOT NULL DEFAULT 'draft',
    priority         VARCHAR(20) NOT NULL DEFAULT 'normal',
    sub_total        DOUBLE PRECISION DEFAULT 0,
    tax_amount       DOUBLE PRECISION DEFAULT 0,
    total            DOUBLE PRECISION DEFAULT 0,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at       TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_workshop_work_orders_organization_id ON workshop_work_orders(organization_id);
CREATE INDEX IF NOT EXISTS idx_workshop_work_orders_customer_id     ON workshop_work_orders(customer_id);
CREATE INDEX IF NOT EXISTS idx_workshop_work_orders_service_bay_id  ON workshop_work_orders(service_bay_id);
CREATE INDEX IF NOT EXISTS idx_workshop_work_orders_technician_id   ON workshop_work_orders(technician_id);
CREATE INDEX IF NOT EXISTS idx_workshop_work_orders_number          ON workshop_work_orders(number);
CREATE INDEX IF NOT EXISTS idx_workshop_work_orders_vehicle_plate   ON workshop_work_orders(vehicle_plate);

CREATE TABLE IF NOT EXISTS workshop_work_order_items (
    id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    created_by_id      UUID,
    work_order_id      UUID NOT NULL,
    item_type          VARCHAR(20) NOT NULL,
    product_variant_id UUID,
    labor_item_id      UUID,
    description        VARCHAR(500) NOT NULL,
    qty                DOUBLE PRECISION DEFAULT 1,
    unit_price         DOUBLE PRECISION DEFAULT 0,
    discount           DOUBLE PRECISION DEFAULT 0,
    total              DOUBLE PRECISION DEFAULT 0,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at         TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_workshop_work_order_items_work_order_id      ON workshop_work_order_items(work_order_id);
CREATE INDEX IF NOT EXISTS idx_workshop_work_order_items_product_variant_id ON workshop_work_order_items(product_variant_id);
CREATE INDEX IF NOT EXISTS idx_workshop_work_order_items_labor_item_id      ON workshop_work_order_items(labor_item_id);

CREATE TABLE IF NOT EXISTS workshop_service_bays (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL,
    created_by_id   UUID,
    name            VARCHAR(100) NOT NULL,
    code            VARCHAR(20),
    description     VARCHAR(300),
    is_active       BOOLEAN DEFAULT true,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at      TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_workshop_service_bays_organization_id ON workshop_service_bays(organization_id);

CREATE TABLE IF NOT EXISTS workshop_labor_items (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL,
    created_by_id   UUID,
    name            VARCHAR(200) NOT NULL,
    code            VARCHAR(50),
    category        VARCHAR(100),
    default_price   DOUBLE PRECISION DEFAULT 0,
    estimated_hours DOUBLE PRECISION DEFAULT 0,
    is_active       BOOLEAN DEFAULT true,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at      TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_workshop_labor_items_organization_id ON workshop_labor_items(organization_id);
CREATE INDEX IF NOT EXISTS idx_workshop_labor_items_code            ON workshop_labor_items(code);
