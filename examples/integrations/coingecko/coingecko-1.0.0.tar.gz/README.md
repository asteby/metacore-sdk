# Precios Crypto (CoinGecko)

Consulta precios actuales de cualquier criptomoneda en USD, MXN u otras divisas. Sin API key requerida.

- Category: `research`
- Tools: 1
