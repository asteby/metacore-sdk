# Resend

Envía correos electrónicos transaccionales con Resend. 100 emails/día gratis.

- Category: `email`
- Tools: 1
