# Búsqueda Google (Serper)

Busca en Google y obtiene resultados actualizados: noticias, precios, eventos. Plan gratuito: 2500 búsquedas/mes.

- Category: `research`
- Tools: 2
