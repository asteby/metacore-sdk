# Telegram

Envía mensajes a grupos o chats de Telegram vía Bot API.

- Category: `communication`
- Tools: 1
